# HeuristiCore Pro: Hybrydowy Agent AI

[](https://www.python.org/downloads/)
[](https://opensource.org/licenses/MIT)
[](https://shields.io/)

**HeuristiCore Pro** to unikalny, hybrydowy framework AI zaprojektowany do automatycznego odkrywania złożonych transformacji na danych binarnych. Zamiast polegać na jednej technice, system ten inteligentnie łączy trzy potężne paradygmaty:

1.  **Reinforcement Learning (RL)** do podejmowania decyzji strategicznych.
2.  **Optymalizację Metaheurystyczną** (GA, SA, ES) do precyzyjnego wyszukiwania taktycznego.
3.  **Logikę Przestrzenną (Krzywa Hilberta)** do rozumienia kontekstu i relacji między danymi.

Celem projektu jest stworzenie agenta, który potrafi nauczyć się, jak przekształcić dowolny 32-bitowy stan binarny `A` w stan `B`, używając do tego sekwencji podstawowych operacji logicznych.

-----

## Architektura Systemu

Cały projekt opiera się na innowacyjnej, trójwarstwowej architekturze, w której każdy moduł pełni wyspecjalizowaną rolę.

### 1\. Warstwa Środowiska: `HilbertNet` (Świat i Fizyka)

To jest fundament, na którym działają pozostałe komponenty.

  * **Świat:** Definiuje przestrzeń problemu. Mapuje 32-bitowe klucze danych na dwuwymiarową "mapę" przy użyciu **Krzywej Hilberta**. Pozwala to agentowi rozumieć "przestrzenną" bliskość danych, a nie tylko ich dystans Hamminga.
  * **Fizyka:** Udostępnia `RuleRegistry` — zestaw podstawowych, atomowych operacji (praw fizyki), które można wykonać na danych (np. `xor`, `and`, `add`, `rotate_l`).

### 2\. Warstwa Strategii: `HeuristiCore` (Strateg)

To jest "mózg" operacji, zaimplementowany jako agent Reinforcement Learning (Actor-Critic).

  * **Zadanie:** Nauczyć się **strategii wysokiego poziomu**.
  * **Proces:** Agent obserwuje stan (np. `current=A`, `target=B`) i decyduje, która reguła z `HilbertNet.RuleRegistry` (np. `'xor'` lub `'add'`) ma największą szansę na przybliżenie go do celu.
  * **Nagroda:** Jest nagradzany nie tylko za zmniejszenie dystansu Hamminga, ale także za **poprawę bliskości przestrzennej** na mapie Hilberta.

### 3\. Warstwa Taktyki: `UniversalBinaryTensor` (Taktyk)

To jest "wyspecjalizowane narzędzie" (lub super-moc) agenta.

  * **Zadanie:** Znaleźć **optymalny 32-bitowy parametr** dla strategii wybranej przez `HeuristiCore`.
  * **Proces:** Gdy `HeuristiCore` wybierze regułę, np. `'xor'`, `UBT` jest wywoływany, aby rozwiązać problem: `A XOR ??? = B`. Uruchamia błyskawiczną optymalizację (przy użyciu **Algorytmów Genetycznych (GA)**, **Symulowanego Wyżarzania (SA)** lub **Strategii Ewolucyjnych (ES)**), aby znaleźć najlepszy możliwy 32-bitowy parametr.

### Przepływ Danych

W skrócie, pojedynczy krok decyzyjny wygląda następująco:

```
(Problem: A -> B)
       |
       v
HeuristiCore (Strateg)
   "Myślę, że użyję 'XOR'!"
       |
       v
UniversalBinaryTensor (Taktyk)
   "Szukam... Znalazłem! Najlepszy parametr to 0xDEADBEEF."
       |
       v
HilbertNet (Świat)
   "Wykonuję: A XOR 0xDEADBEEF = C"
       |
       v
HeuristiCore (Strateg)
   "Świetnie! Nowy stan C jest bliżej B. Nagroda +10."
```

-----

## Kluczowe Funkcje

  * **Hybrydowa Inteligencja:** Łączy RL (do nauki "co robić") z optymalizacją metaheurystyczną (do nauki "jak to zrobić"), co pozwala rozwiązywać problemy o gigantycznej przestrzeni stanów ($2^{32}$).
  * **Świadomość Przestrzenna:** Wykorzystanie Krzywej Hilberta pozwala agentowi znaleźć bardziej "logiczne" lub "numerycznie bliskie" transformacje, których nie widać w standardowym dystansie Hamminga.
  * **Uczenie na Rzeczywistych Danych:** `UserDataAnalyzer` skanuje pliki binarne (`.exe`, `.dll`, `.png`) na dysku użytkownika, aby wyodrębnić rzeczywiste wzorce transformacji i użyć ich jako zadań treningowych.
  * **Curriculum Learning:** Agent uczy się najpierw na prostych transformacjach odkrytych w danych użytkownika, zanim przejdzie do bardziej złożonych zadań.
  * **Optymalizacja Wielokryterialna:** Agent jest nagradzany za trzy rzeczy jednocześnie: zmniejszenie dystansu do celu, poprawę bliskości przestrzennej i prostotę znalezionego parametru.
  * **Modularność:** `RuleRegistry` w `HilbertNet` pozwala na łatwe dodawanie nowych, niestandardowych operacji bitowych, które agent może się nauczyć wykorzystywać.
  * **Wgląd i Analiza:** `UniversalBinaryTensor` zawiera zaawansowane narzędzia do analizy statystycznej wzorców binarnych (entropia, korelacje bitów, klastrowanie).

-----

## Instalacja i Uruchomienie

Projekt wymaga Pythona 3.9+ oraz bibliotek `numpy` i `numba`.

1.  Sklonuj repozytorium:

    ```bash
    git clone https://github.com/twoja/nazwa/heuristicore.git
    cd heuristicore
    ```

2.  Zainstaluj zależności:

    ```bash
    pip install numpy numba
    ```

3.  Uruchom główny skrypt agenta:

      * **Tryb syntetyczny** (trening na losowych danych, jeśli nie masz pod ręką plików binarnych):

        ```bash
        python heuristicore_v2.py
        ```

      * **Tryb nauki na danych** (rekomendowany, skanuje wskazany folder w poszukiwaniu wzorców):

        ```bash
        python heuristicore_v2.py /sciezka/do/twoich/plikow_binarnych/
        ```

Po zakończeniu treningu, system przechodzi w tryb interaktywny, pozwalając na dalszą analizę i testowanie wytrenowanego agenta.

-----

## Potencjalne Kierunki Rozwoju i Zastosowania

Ten projekt jest solidną podstawą dla wielu zaawansowanych aplikacji.

### Możliwości Zastosowania

  * **Inżynieria Wsteczna (Reverse Engineering):** Automatyczne odkrywanie logiki w nieudokumentowanych formatach plików lub protokołach sieciowych (np. "Jak pakiet A zamienia się w pakiet B?").
  * **Analiza Malware'u:** Pomoc w zrozumieniu algorytmów obfuskacji lub prostych szyfrów XOR używanych przez złośliwe oprogramowanie.
  * **Kompresja Danych:** Identyfikacja powtarzalnych, złożonych transformacji, które można zapisać jako pojedynczą regułę.
  * **Generowanie Proceduralne:** Odkrywanie sekwencji reguł, które generują złożone wzorce graficzne lub muzyczne z prostych danych wejściowych.
  * **Automatyzacja Optymalizacji Kodu:** Znajdowanie sekwencji operacji bitowych, które są bardziej wydajne niż oryginalny kod.

### Kierunki Rozwoju

  * **Wymiana `SimpleNN` na PyTorch/TensorFlow:** Obecny "Strateg" (`SimpleNN`) jest zaimplementowany w `numpy`. Zastąpienie go nowoczesną biblioteką (np. PyTorch) pozwoliłoby na użycie znacznie potężniejszych architektur (np. **Graph Neural Networks** do analizy relacji przestrzennych w `HilbertNet` lub **Transformerów** do analizy sekwencji reguł).
  * **Wspominanie o PyTorch/TensorFlow jest trafne, gdy mówimy o optymalizacji technicznej obecnego modelu neuronowego (SimpleNN). Wspominanie o DRMSystem jest trafne, gdy mówimy o rewolucji koncepcyjnej, czyli wymianie całego paradygmatu podejmowania decyzji (z wag na reguły). Obie propozycje są ważnymi i logicznymi kierunkami rozwoju Twojego systemu. Dodając DRM jako oddzielny, unikalny i bardziej zaawansowany kierunek, podkreślasz głębię i potencjał architektury opartej na regułach.
  * **Obliczenia Rozproszone:** Optymalizacja w `UniversalBinaryTensor` (szczególnie Algorytm Genetyczny) jest idealnym kandydatem do zrównoleglenia i rozproszenia na wiele rdzeni CPU lub nawet maszyn.
  * **Akceleracja Sprzętowa:** Przeniesienie kluczowych pętli optymalizacyjnych z `UBT` oraz operacji na `HilbertNet` do **CUDA**, aby w pełni wykorzystać moc GPU.
  * **Rozbudowa `RuleRegistry`:** Dodanie bardziej złożonych "atomowych" reguł do `HilbertNet`, takich jak podstawowe operacje kryptograficzne (AES round), operacje na liczbach zmiennoprzecinkowych czy funkcje skrótu.
  * **Wizualny Interfejs:** Stworzenie interfejsu graficznego (np. w `PyQt` lub `Streamlit`), który renderowałby mapę Hilberta w czasie rzeczywistym i pokazywał, jak agent "podróżuje" po przestrzeni binarnej, transformując dane.